API_KEY = '4d299d46-c93b-11ea-9efd-0242ac130002-4d299e04-c93b-11ea-9efd-0242ac130002'
BASE_URL = f'https://api.stormglass.io/v2/weather/point'
AUTHORISATION ={'Authorization': API_KEY}