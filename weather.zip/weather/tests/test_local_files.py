import pytest
import requests
import os.path

from weather.table_creator.local_files.local_files import LocalFiles


def test_get_values():
    ob1 = LocalFiles()
    ob1.get_values(56.85, 60.61, '2018-07-16', '2018-07-17')
    assert len(ob1.time_point) == 25, '''Values don't write'''

    if ob1.transformation():
        check = 1
    else:
        check = 0
    assert check == 1, '''Text of file doesn't create'''

    name_check = ob1.create_name()
    assert len(name_check) > 21, 'Wrong name of file'
    assert len(name_check) < 40, 'Wrong name of file'

    ob1.record()
    assert os.path.exists(f'{ob1.name_file}.csv') == True, '''File didn't created'''
