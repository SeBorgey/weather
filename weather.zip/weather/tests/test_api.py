import pytest
import requests

from weather.table_creator.api.api import API

def test_send_request():
    ob1 = API()
    correct = str(ob1.send_request(56.85, 60.61, '2018-07-16', '2018-07-17'))
    assert correct == '<Response [200]>', 'Неверный ответ от сервера'
